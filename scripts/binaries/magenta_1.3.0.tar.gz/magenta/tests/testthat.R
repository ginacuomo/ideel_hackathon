library(testthat)
library(magenta)

test_check("magenta")
